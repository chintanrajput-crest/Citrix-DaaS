import json
import time
import requests

# --- Config ---
DEST_API_URL = ""
DEST_API_KEY = ""
DEST_APP_KEY = ""

INPUT_FILE = "pipelines.json"

HEADERS_TEMPLATE = {
    "Content-Type": "application/json",
}


def import_pipeline(pipeline):
    if pipeline.get("is_read_only"):
        print(f"Skipping read-only pipeline: {pipeline.get('name')}")
        return

    for field in ["id", "is_read_only", "type"]:
        pipeline.pop(field, None)

    url = f"{DEST_API_URL}/api/v1/logs/config/pipelines"
    headers = {
        **HEADERS_TEMPLATE,
        "DD-API-KEY": DEST_API_KEY,
        "DD-APPLICATION-KEY": DEST_APP_KEY,
    }

    while True:
        response = requests.post(url, headers=headers, json=pipeline)
        if response.status_code == 429:
            print(
                f"Rate limit hit while importing '{pipeline.get('name')}'. Waiting 20 seconds..."
            )
            time.sleep(20)
            continue
        elif response.ok:
            print(f"Imported: {pipeline.get('name')}")
        else:
            print(
                f"Failed to import '{pipeline.get('name')}': {response.status_code} - {response.text}"
            )
        break


def main():
    with open(INPUT_FILE, "r") as f:
        pipelines = json.load(f)

    print(f"Importing {len(pipelines)} pipeline(s) from {INPUT_FILE}...")
    for pipeline in pipelines:
        import_pipeline(pipeline)


if __name__ == "__main__":
    main()
