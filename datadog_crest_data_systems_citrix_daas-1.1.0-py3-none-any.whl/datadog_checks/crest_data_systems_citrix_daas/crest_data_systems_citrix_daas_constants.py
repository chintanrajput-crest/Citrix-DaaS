# Copyright (C) 2026 Crest Data.
# All rights reserved

"""Constants for Citrix DaaS integration."""

# Log message format
LOG_MESSAGE_FORMAT = "({}:{}) | Citrix DaaS | MESSAGE = {}"

# Service check names
STATUS_CHECK_NAME = "status"
CAN_CONNECT_CHECK_NAME = "can_connect"

# Integration prefix and source type
INTEGRATION_PREFIX = "cds.citrix_daas"
SOURCE_TYPE_NAME = "crest_data_systems_citrix_daas"

# API validation constants
API_VAL_TAG = ["tag:datadog_keys_validation"]
API_VAL_TITLE = "Datadog API key validation"
API_VAL_SOURCE_TYPE = f"{INTEGRATION_PREFIX}.datadog_keys_validation"

# Configuration validation constants
CONF_VAL_TAG = ["tag:citrix_daas_conf_validation"]
CONF_VAL_TITLE = "Citrix DaaS configuration validation check"
CONF_VAL_SOURCE_TYPE = f"{INTEGRATION_PREFIX}.citrix_daas_conf_validation"

# Timestamp formats
CITRIX_TIMESTAMP_FORMAT = "%Y-%m-%dT%H:%M:%S.%fZ"
CITRIX_FILTER_FORMAT = "%Y-%m-%dT%H:%M:%S.%fZ"

# API retry constants
MAX_RETRIES = 5
WAIT_FOR = 3
STATUS_TO_RETRY = [429, 500, 502, 503, 504]

# HTTP configuration
HTTP_TIMEOUT = 30
VERIFY_SSL = True
CONTENT_TYPE = "application/json"
TOKENS_CONTENT_TYPE = "application/x-www-form-urlencoded"

# Citrix Cloud API Base URLs by region
BASE_URLS = {
    "US": "https://api.cloud.com",
    "EU": "https://api.eu.cloud.com",
    "AP-S": "https://api.ap-s.cloud.com",
    "JP": "https://api.citrixcloud.jp",
}

AUTH_BASE_URLS = {"US": "https://api.cloud.com", "JP": "https://api.citrixcloud.jp"}


ODATA_TOP = "$top"
ODATA_SKIP = "$skip"
ODATA_FILTER = "$filter"
ODATA_EXPAND = "$expand"
ODATA_ORDERBY = "$orderby"

# Data type constants
SESSIONS_DATA_TYPE = "sessions"
SESSION_METRICS_DATA_TYPE = "sessionmetrics"
APPLICATION_ACTIVITY_SUMMARIES_DATA_TYPE = "applicationactivitysummaries"
APPLICATION_ERRORS_DATA_TYPE = "applicationerrors"
APPLICATION_FAULTS_DATA_TYPE = "applicationfaults"
APPLICATION_INSTANCES_DATA_TYPE = "applicationinstances"
RESOURCE_UTILIZATION_SUMMARY_DATA_TYPE = "resourceutilizationsummary"
MACHINE_METRIC_SUMMARY_DATA_TYPE = "machinemetricsummary"
CONFIG_LOG_OPERATIONS_DATA_TYPE = "configlogoperations"
CONNECTIONS_DATA_TYPE = "connections"

# Checkpoint field names
SESSIONS_CHECKPOINT_FIELD = "EndDate"
SESSION_METRICS_CHECKPOINT_FIELD = "CollectedDate"
APPLICATION_ACTIVITY_SUMMARIES_CHECKPOINT_FIELD = "ModifiedDate"
APPLICATION_ERRORS_CHECKPOINT_FIELD = "ErrorReportedDate"
APPLICATION_FAULTS_CHECKPOINT_FIELD = "FaultReportedDate"
APPLICATION_INSTANCES_CHECKPOINT_FIELD = "ModifiedDate"
RESOURCE_UTILIZATION_SUMMARY_CHECKPOINT_FIELD = "SummaryDate"
MACHINE_METRIC_SUMMARY_CHECKPOINT_FIELD = "SummaryDate"
CONFIG_LOG_OPERATIONS_CHECKPOINT_FIELD = "EndTime"
CONNECTIONS_CHECKPOINT_FIELD = "ModifiedDate"

# Pagination constants
PAGE_SIZE = 1000

# OAuth token endpoint
TOKEN_ENDPOINT = "/cctrustoauth2/{customer_id}/tokens/clients"

# API endpoints
ME_API_ENDPOINT = "/cvad/manage/me"
SESSIONS_API_ENDPOINT = "/monitorodata/Sessions"
SESSION_METRICS_API_ENDPOINT = "/monitorodata/SessionMetrics"
APPLICATION_ACTIVITY_SUMMARIES_API_ENDPOINT = "/monitorodata/ApplicationActivitySummaries"
APPLICATION_ERRORS_API_ENDPOINT = "/monitorodata/ApplicationErrors"
APPLICATION_FAULTS_API_ENDPOINT = "/monitorodata/ApplicationFaults"
APPLICATION_INSTANCES_API_ENDPOINT = "/monitorodata/ApplicationInstances"
RESOURCE_UTILIZATION_SUMMARY_API_ENDPOINT = "/monitorodata/ResourceUtilizationSummary"
MACHINE_METRIC_SUMMARY_API_ENDPOINT = "/monitorodata/MachineMetricSummary"
CONFIG_LOG_OPERATIONS_API_ENDPOINT = "/cvad/manage/ConfigLog/Operations/$search"
CONNECTIONS_API_ENDPOINT = "/monitorodata/Connections"

# Data collection types
ALLOWED_DATA_TO_COLLECT = [
    SESSIONS_DATA_TYPE,
    SESSION_METRICS_DATA_TYPE,
    APPLICATION_ACTIVITY_SUMMARIES_DATA_TYPE,
    APPLICATION_ERRORS_DATA_TYPE,
    APPLICATION_FAULTS_DATA_TYPE,
    APPLICATION_INSTANCES_DATA_TYPE,
    RESOURCE_UTILIZATION_SUMMARY_DATA_TYPE,
    MACHINE_METRIC_SUMMARY_DATA_TYPE,
    CONFIG_LOG_OPERATIONS_DATA_TYPE,
    CONNECTIONS_DATA_TYPE,
]
