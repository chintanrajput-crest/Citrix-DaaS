# Copyright (C) 2026 Crest Data.
# All rights reserved

__version__ = "1.1.0"
