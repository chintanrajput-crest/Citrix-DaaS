# Copyright (C) 2026 Crest Data.
# All rights reserved

"""Dataset configurations for Citrix DaaS integration."""

# Each standard dataset entry carries the three variables that distinguish its ingest call:
#   checkpoint_field – OData field used for both the $filter and $orderby parameters,
#                      and the key whose value is stored as the new checkpoint.
#   api_method       – Name of the CitrixDaasAPI method to call (resolved via getattr).
# Entries that omit these keys (e.g. configlogoperations) require custom ingest logic.
API_CONFIG = [
    {
        "dataset": "sessions",
        "checkpoint_field": "EndDate",
        "api_method": "get_sessions",
    },
    {
        "dataset": "sessionmetrics",
        "checkpoint_field": "CollectedDate",
        "api_method": "get_session_metrics",
    },
    {
        "dataset": "applicationactivitysummaries",
        "checkpoint_field": "ModifiedDate",
        "api_method": "get_application_activity_summaries",
    },
    {
        "dataset": "applicationerrors",
        "checkpoint_field": "ErrorReportedDate",
        "api_method": "get_application_errors",
    },
    {
        "dataset": "applicationfaults",
        "checkpoint_field": "FaultReportedDate",
        "api_method": "get_application_faults",
    },
    {
        "dataset": "applicationinstances",
        "checkpoint_field": "ModifiedDate",
        "api_method": "get_application_instances",
    },
    {
        "dataset": "resourceutilizationsummary",
        "checkpoint_field": "SummaryDate",
        "api_method": "get_resource_utilization_summary",
    },
    {
        "dataset": "machinemetricsummary",
        "checkpoint_field": "SummaryDate",
        "api_method": "get_machine_metric_summary",
    },
    {
        "dataset": "configlogoperations",
    },
    {
        "dataset": "connections",
        "checkpoint_field": "ModifiedDate",
        "api_method": "get_connections",
    },
]

# Lookup by dataset name for O(1) access in the ingest path.
DATASET_CONFIG_MAP = {entry["dataset"]: entry for entry in API_CONFIG}
