# Copyright (C) 2026 Crest Data.
# All rights reserved

"""Low-level API client module for Citrix DaaS REST API communication."""

import time
from datetime import datetime, timedelta, timezone

from datadog_checks.base.errors import ConfigurationError

from . import crest_data_systems_citrix_daas_constants as constants
from .crest_data_systems_citrix_daas_errors import AuthenticationError


class CitrixDaasAPI:
    """Handles OAuth authentication and HTTP requests to Citrix DaaS REST APIs."""

    def __init__(
        self,
        instance_check,
        client_id,
        client_secret,
        customer_id,
        region="US",
        client_settings=None,
    ):
        """Initialize the Citrix DaaS API client.

        Args:
            instance_check: The Datadog check instance object.
            client_id: OAuth client ID.
            client_secret: OAuth client secret.
            customer_id: Citrix customer ID.
            region: Region for API base URL (US, EU, AP-S, JP).
            client_settings: Optional HTTP client settings.
        """
        self.instance_check = instance_check
        self.client_id = client_id
        self.client_secret = client_secret
        self.customer_id = customer_id
        self.region = region

        self.base_url = constants.BASE_URLS.get(region, constants.BASE_URLS["US"])
        self.auth_base_url = constants.AUTH_BASE_URLS.get(region, constants.AUTH_BASE_URLS["US"])

        self.client_settings = client_settings or {}
        self.client_settings.setdefault("verify", constants.VERIFY_SSL)
        self.client_settings.setdefault("timeout", (constants.HTTP_TIMEOUT, constants.HTTP_TIMEOUT))

        self.access_token = None
        # instance_ids is now a list to support multiple sites
        self.instance_ids = {}
        self.headers = {
            "Content-Type": constants.CONTENT_TYPE,
            "Accept": constants.CONTENT_TYPE,
        }

    def get_last_18h_timestamp(self, date_format):
        """Get timestamp for last 18 hours for initial checkpoint.

        Args:
            date_format: The format string for the timestamp.

        Returns:
            str: Timestamp for 18 hours ago.
        """
        dt = datetime.now(timezone.utc) - timedelta(hours=18)
        return dt.strftime(date_format)

    def authenticate(self):
        """Authenticate with Citrix Cloud using OAuth 2.0.

        This method performs OAuth 2.0 client credentials flow to obtain an access token
        from Citrix Cloud. The token is then used to authenticate all subsequent API calls.
        After obtaining the token, it also retrieves the instance ID using the /me endpoint.
        """
        # Build token endpoint URL with customer ID
        token_url = self.auth_base_url + constants.TOKEN_ENDPOINT.format(customer_id=self.customer_id)

        # Prepare OAuth 2.0 client credentials payload
        payload = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }

        try:
            # Make POST request to token endpoint
            response = self.instance_check.http.post(
                token_url,
                data=payload,
                headers={
                    "Content-Type": constants.TOKENS_CONTENT_TYPE,
                    "Accept": constants.CONTENT_TYPE,
                },
                **self.client_settings,
            )
            response.raise_for_status()
            token_data = response.json()
            self.access_token = token_data.get("access_token")

            # Validate that we received an access token
            if not self.access_token:
                raise AuthenticationError(
                    "Failed to obtain access token from Citrix Cloud. Please re-check the configuration parameters."
                )

            # Set authorization header for all future requests
            self.headers["Authorization"] = f"CWSAuth Bearer={self.access_token}"

        except Exception as e:
            error_msg = f"Authentication failed: {e}. Please re-check the configuration parameters."
            self.instance_check.logger.error(error_msg)
            raise AuthenticationError(error_msg)

        # Retrieve instance ID after successful authentication
        return self.get_instance_id()

    def _prepare_me_headers(self):
        """Prepare headers for /me endpoint request."""
        headers = self.headers.copy()
        headers["Citrix-CustomerId"] = self.customer_id
        return headers

    def _make_me_request(self, me_url, headers):
        """Make request to /me endpoint."""
        return self._retry_request(
            self.instance_check.http.get,
            me_url,
            headers=headers,
            client_settings=self.client_settings,
        )

    def _extract_instance_ids(self, response):
        """Extract instance IDs from /me endpoint response."""
        if not response or "Customers" not in response:
            raise AuthenticationError("Failed to retrieve Instance IDs from /me endpoint")

        customers = response.get("Customers", [])
        if not customers:
            raise AuthenticationError("No valid sites found. Check customer configuration.")

        customer = customers[0]  # Primary customer
        sites = customer.get("Sites", [])

        for site in sites:
            site_info = self._extract_site_info(site)
            if site_info:
                self.instance_ids[site_info["id"]] = site_info["name"]

        if not self.instance_ids:
            raise AuthenticationError("No valid sites found in customer data.")

        info_msg = f"Retrieved '{len(self.instance_ids)}' Instance ID(s): {self.instance_ids}"
        self.instance_check.logger.info(info_msg)
        return self.instance_ids

    def _extract_site_info(self, site):
        """Extract site ID and name from site data."""
        site_lower = {key.lower(): value for key, value in site.items()}
        site_id = site_lower.get("id")
        site_name = site_lower.get("name")

        if site_id and site_name:
            return {"id": site_id, "name": site_name}
        return None

    def get_instance_id(self):
        """Get the instance IDs using /me endpoint."""
        me_url = self.base_url + constants.ME_API_ENDPOINT

        try:
            headers = self._prepare_me_headers()
            response = self._make_me_request(me_url, headers)
            return self._extract_instance_ids(response)

        except Exception as e:
            error_msg = f"Failed to get instance IDs: {e}"
            self.instance_check.logger.error(error_msg)
            raise

    def handle_retries(self, error, status_code, retries, wait_for, status_to_retry):
        """Handle retry logic for failed requests.

        This method implements exponential backoff retry logic for transient errors.
        It determines whether to retry based on the HTTP status code and calculates
        the appropriate wait time before the next retry attempt.

        Args:
            error: The exception that occurred.
            status_code: HTTP status code from the failed request.
            retries: Current retry count.
            wait_for: Base wait time in seconds.
            status_to_retry: List of HTTP status codes that should trigger a retry.

        Returns:
            int or None: Updated retry count if retry should continue, None to stop retrying.
        """
        if status_code in status_to_retry:
            wait_time = wait_for * (2**retries)
            time.sleep(wait_time)
            retries += 1
            self.instance_check.logger.info(f"Retry attempt {retries}")  # noqa: G004
            return retries
        elif status_code in [400, 401, 403]:
            err_msg = f"Configuration error - Status {status_code}: {error}"
            self.instance_check.logger.error(err_msg)
            raise ConfigurationError(err_msg)
        else:
            err_msg = f"Unexpected error - Status {status_code}: {error}"
            self.instance_check.logger.error(err_msg)
            return None

    def _retry_request(self, http_func, url, headers=None, params=None, client_settings=None, **kwargs):
        """Retry wrapper for HTTP requests.

        This method wraps HTTP requests with retry logic to handle transient failures.
        It implements exponential backoff and retries on specific HTTP status codes.

        Args:
            http_func: HTTP function to call (e.g., self.instance_check.http.get).
            url: Request URL.
            headers: HTTP headers dictionary.
            params: Query parameters dictionary.
            client_settings: Client settings (timeout, verify, etc.).
            **kwargs: Additional arguments to pass to the HTTP function.

        Returns:
            dict: JSON response from the API, or None if all retries failed.
        """
        retries = 0
        client_settings = client_settings or {}
        max_retries = constants.MAX_RETRIES
        status_to_retry = constants.STATUS_TO_RETRY
        wait_for = constants.WAIT_FOR

        while retries < max_retries:
            try:
                response = http_func(url, headers=headers, params=params, **client_settings, **kwargs)
                response.raise_for_status()
                return response.json()
            except Exception as error:
                status_code = getattr(getattr(error, "response", None), "status_code", None)
                result = self.handle_retries(error, status_code, retries, wait_for, status_to_retry)
                if result is None:
                    return None
                retries = result

        if retries >= max_retries:
            self.instance_check.logger.error("Max retry attempts exceeded")
        return None

    def get_sessions(self, filter_param, top, skip, orderby=None):
        """Get sessions data from Citrix DaaS.

        This method calls the /monitorodata/Sessions endpoint to retrieve session data.
        It supports OData query parameters for filtering, pagination, expansion, and ordering.

        Args:
            filter_param: OData $filter parameter for filtering results.
            top: Number of records to return per page ($top parameter).
            skip: Number of records to skip for pagination ($skip parameter).
            expand: OData $expand parameter to include related entities.
            orderby: OData $orderby parameter for sorting results.

        Returns:
            dict: API response containing sessions data in 'value' field.
        """
        url = self.base_url + constants.SESSIONS_API_ENDPOINT

        params = {
            constants.ODATA_TOP: top,
            constants.ODATA_SKIP: skip,
            constants.ODATA_EXPAND: "Machine($select=*;$expand=DesktopGroup($select=Name)),User($select=*)",
        }

        if filter_param:
            params[constants.ODATA_FILTER] = filter_param
        if orderby:
            params[constants.ODATA_ORDERBY] = orderby

        headers = self.headers.copy()
        headers["Citrix-CustomerId"] = self.customer_id

        return self._retry_request(
            self.instance_check.http.get,
            url,
            headers=headers,
            params=params,
            client_settings=self.client_settings,
        )

    def get_session_metrics(self, filter_param, top, skip, orderby=None):
        """Get session metrics data from Citrix DaaS.

        This method calls the /monitorodata/SessionMetrics endpoint to retrieve session metrics.
        It supports OData query parameters for filtering, pagination, expansion, and ordering.

        Args:
            filter_param: OData $filter parameter for filtering results.
            top: Number of records to return per page ($top parameter).
            skip: Number of records to skip for pagination ($skip parameter).
            expand: OData $expand parameter to include related entities.
            orderby: OData $orderby parameter for sorting results.

        Returns:
            dict: API response containing session metrics data in 'value' field.
        """
        url = self.base_url + constants.SESSION_METRICS_API_ENDPOINT

        params = {
            constants.ODATA_TOP: top,
            constants.ODATA_SKIP: skip,
            constants.ODATA_EXPAND: "Session($expand=Machine($select=Id,Name,IPAddress),User($select=UserName,Upn,Id))",
        }

        if filter_param:
            params[constants.ODATA_FILTER] = filter_param
        if orderby:
            params[constants.ODATA_ORDERBY] = orderby

        headers = self.headers.copy()
        headers["Citrix-CustomerId"] = self.customer_id

        return self._retry_request(
            self.instance_check.http.get,
            url,
            headers=headers,
            params=params,
            client_settings=self.client_settings,
        )

    def get_application_activity_summaries(self, filter_param, top, skip, orderby=None):
        """Get application activity summaries data from Citrix DaaS.

        This method calls the /monitorodata/ApplicationActivitySummaries endpoint to retrieve
        application activity summary data. It supports OData query parameters for filtering,
        pagination, and ordering.

        Args:
            filter_param: OData $filter parameter for filtering results.
            top: Number of records to return per page ($top parameter).
            skip: Number of records to skip for pagination ($skip parameter).
            orderby: OData $orderby parameter for sorting results.

        Returns:
            dict: API response containing application activity summaries data in 'value' field.
        """
        url = self.base_url + constants.APPLICATION_ACTIVITY_SUMMARIES_API_ENDPOINT

        params = {
            constants.ODATA_TOP: top,
            constants.ODATA_SKIP: skip,
            constants.ODATA_EXPAND: (
                "Application($select=*),DesktopGroup($select=Id,Name;$expand=Machines($select=Id,Name,IPAddress))"
            ),
        }

        if filter_param:
            params[constants.ODATA_FILTER] = filter_param
        if orderby:
            params[constants.ODATA_ORDERBY] = orderby

        headers = self.headers.copy()
        headers["Citrix-CustomerId"] = self.customer_id

        return self._retry_request(
            self.instance_check.http.get,
            url,
            headers=headers,
            params=params,
            client_settings=self.client_settings,
        )

    def get_application_errors(self, filter_param, top, skip, orderby=None):
        """Get application errors data from Citrix DaaS.

        Args:
            filter_param: OData $filter parameter for filtering results.
            top: Number of records to return per page ($top parameter).
            skip: Number of records to skip for pagination ($skip parameter).
            orderby: OData $orderby parameter for sorting results.

        Returns:
            dict: API response containing application errors data in 'value' field.
        """
        url = self.base_url + constants.APPLICATION_ERRORS_API_ENDPOINT

        params = {
            constants.ODATA_TOP: top,
            constants.ODATA_SKIP: skip,
            constants.ODATA_EXPAND: (
                "Session($select=SessionKey;$expand=User($select=Id,UserName,Upn)),Machine($select=Name,IPAddress)"
            ),
        }

        if filter_param:
            params[constants.ODATA_FILTER] = filter_param
        if orderby:
            params[constants.ODATA_ORDERBY] = orderby

        headers = self.headers.copy()
        headers["Citrix-CustomerId"] = self.customer_id

        return self._retry_request(
            self.instance_check.http.get,
            url,
            headers=headers,
            params=params,
            client_settings=self.client_settings,
        )

    def get_application_faults(self, filter_param, top, skip, orderby=None):
        """Get application faults data from Citrix DaaS.

        Args:
            filter_param: OData $filter parameter for filtering results.
            top: Number of records to return per page ($top parameter).
            skip: Number of records to skip for pagination ($skip parameter).
            orderby: OData $orderby parameter for sorting results.

        Returns:
            dict: API response containing application faults data in 'value' field.
        """
        url = self.base_url + constants.APPLICATION_FAULTS_API_ENDPOINT

        params = {
            constants.ODATA_TOP: top,
            constants.ODATA_SKIP: skip,
            constants.ODATA_EXPAND: (
                "Session($select=SessionKey;$expand=User($select=Id,UserName,Upn)),Machine($select=Name,IPAddress)"
            ),
        }

        if filter_param:
            params[constants.ODATA_FILTER] = filter_param
        if orderby:
            params[constants.ODATA_ORDERBY] = orderby

        headers = self.headers.copy()
        headers["Citrix-CustomerId"] = self.customer_id

        return self._retry_request(
            self.instance_check.http.get,
            url,
            headers=headers,
            params=params,
            client_settings=self.client_settings,
        )

    def get_application_instances(self, filter_param, top, skip, orderby=None):
        """Get application instances data from Citrix DaaS.

        Args:
            filter_param: OData $filter parameter for filtering results.
            top: Number of records to return per page ($top parameter).
            skip: Number of records to skip for pagination ($skip parameter).
            orderby: OData $orderby parameter for sorting results.

        Returns:
            dict: API response containing application instances data in 'value' field.
        """
        url = self.base_url + constants.APPLICATION_INSTANCES_API_ENDPOINT

        params = {
            constants.ODATA_TOP: top,
            constants.ODATA_SKIP: skip,
            constants.ODATA_EXPAND: (
                "Application($select=*),"
                "Session($select=SessionKey;$expand=User($select=Id,Upn,UserName),Machine($select=Name,IPAddress))"
            ),
        }

        if filter_param:
            params[constants.ODATA_FILTER] = filter_param
        if orderby:
            params[constants.ODATA_ORDERBY] = orderby

        headers = self.headers.copy()
        headers["Citrix-CustomerId"] = self.customer_id

        return self._retry_request(
            self.instance_check.http.get,
            url,
            headers=headers,
            params=params,
            client_settings=self.client_settings,
        )

    def get_resource_utilization_summary(self, filter_param, top, skip, orderby=None):
        """Get resource utilization summary data from Citrix DaaS.

        This method calls the /monitorodata/ResourceUtilizationSummary endpoint to retrieve
        resource utilization summary data. It supports OData query parameters for filtering,
        pagination, and ordering.

        Args:
            filter_param: OData $filter parameter for filtering results.
            top: Number of records to return per page ($top parameter).
            skip: Number of records to skip for pagination ($skip parameter).
            orderby: OData $orderby parameter for sorting results.

        Returns:
            dict: API response containing resource utilization summary data in 'value' field.
        """
        url = self.base_url + constants.RESOURCE_UTILIZATION_SUMMARY_API_ENDPOINT

        params = {
            constants.ODATA_TOP: top,
            constants.ODATA_SKIP: skip,
            constants.ODATA_EXPAND: "Machine($select=Id,Name,IPAddress),DesktopGroup($select=Id,Name)",
        }

        if filter_param:
            params[constants.ODATA_FILTER] = filter_param
        if orderby:
            params[constants.ODATA_ORDERBY] = orderby

        headers = self.headers.copy()
        headers["Citrix-CustomerId"] = self.customer_id

        return self._retry_request(
            self.instance_check.http.get,
            url,
            headers=headers,
            params=params,
            client_settings=self.client_settings,
        )

    def get_machine_metric_summary(self, filter_param, top, skip, orderby=None):
        """Get machine metric summary data from Citrix DaaS.

        This method calls the /monitorodata/MachineMetricSummary endpoint to retrieve
        machine metric summary data. It supports OData query parameters for filtering,
        pagination, and ordering.

        Args:
            filter_param: OData $filter parameter for filtering results.
            top: Number of records to return per page ($top parameter).
            skip: Number of records to skip for pagination ($skip parameter).
            orderby: OData $orderby parameter for sorting results.

        Returns:
            dict: API response containing machine metric summary data in 'value' field.
        """
        url = self.base_url + constants.MACHINE_METRIC_SUMMARY_API_ENDPOINT

        params = {
            constants.ODATA_TOP: top,
            constants.ODATA_SKIP: skip,
            constants.ODATA_EXPAND: "Machine($select=Id,Name,IPAddress;$expand=DesktopGroup($select=Id,Name))",
        }

        if filter_param:
            params[constants.ODATA_FILTER] = filter_param
        if orderby:
            params[constants.ODATA_ORDERBY] = orderby

        headers = self.headers.copy()
        headers["Citrix-CustomerId"] = self.customer_id

        return self._retry_request(
            self.instance_check.http.get,
            url,
            headers=headers,
            params=params,
            client_settings=self.client_settings,
        )

    def get_config_log_operations(self, instance_id, end_time_filter, continuation_token=None):
        """Get ConfigLog operations data from Citrix DaaS using POST $search.

        This method calls the /cvad/manage/ConfigLog/Operations/$search endpoint to retrieve
        configuration log operations. This API uses POST with search filters and continuation
        tokens for pagination, and requires per-site-ID execution.

        Args:
            instance_id: Site ID to fetch data for (passed in Citrix-InstanceId header).
            end_time_filter: EndTime value to filter records (format: "%Y-%m-%dT%H:%M:%S.%fZ").
            continuation_token: Token for pagination (None for first page).

        Returns:
            dict: API response containing operations data in 'Items' field and continuation token.
        """
        url = self.base_url + constants.CONFIG_LOG_OPERATIONS_API_ENDPOINT

        request_body = {
            "SearchFilters": [{"Property": "EndTime", "Value": end_time_filter, "Operator": "GreaterThan"}],
            "SortCriteria": {"Property": "EndTime", "SortDirection": "Ascending"},
        }

        params = {}
        if continuation_token:
            params["continuationToken"] = continuation_token

        headers = self.headers.copy()
        headers["Citrix-CustomerId"] = self.customer_id
        headers["Citrix-InstanceId"] = instance_id
        headers["Content-Type"] = "application/json"

        return self._retry_request(
            self.instance_check.http.post,
            url,
            headers=headers,
            params=params,
            json=request_body,
            client_settings=self.client_settings,
        )

    def get_connections(self, filter_param, top, skip, orderby=None):
        """Get connections data from Citrix DaaS.

        This method calls the /monitorodata/Connections endpoint to retrieve
        connections data. It supports OData query parameters for filtering,
        pagination, and ordering.

        Args:
            filter_param: OData $filter parameter for filtering results.
            top: Number of records to return per page ($top parameter).
            skip: Number of records to skip for pagination ($skip parameter).
            orderby: OData $orderby parameter for sorting results.

        Returns:
            dict: API response containing connections data in 'value' field.
        """
        url = self.base_url + constants.CONNECTIONS_API_ENDPOINT

        params = {
            constants.ODATA_TOP: top,
            constants.ODATA_SKIP: skip,
            constants.ODATA_EXPAND: (
                "Session($select=SessionKey;$expand=Machine($select=Id,Name,IPAddress),User($select=UserName,Upn,Id))"
            ),
        }

        if filter_param:
            params[constants.ODATA_FILTER] = filter_param
        if orderby:
            params[constants.ODATA_ORDERBY] = orderby

        headers = self.headers.copy()
        headers["Citrix-CustomerId"] = self.customer_id

        return self._retry_request(
            self.instance_check.http.get,
            url,
            headers=headers,
            params=params,
            client_settings=self.client_settings,
        )
