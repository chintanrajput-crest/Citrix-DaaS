# Copyright (C) 2026 Crest Data.
# All rights reserved

"""Custom exceptions for Citrix DaaS integration."""


class DatadogAPIError(Exception):
    """Base exception class for Datadog API client."""

    def __init__(self, *args):
        """Initialize the exception.

        Args:
            *args: Exception arguments.
        """
        super().__init__(*args)


class InvalidAPIKeyError(DatadogAPIError):
    """Raised when Datadog API key validation fails."""


class InvalidKeyError(DatadogAPIError):
    """Raised when configuration key validation fails."""


class AuthenticationError(DatadogAPIError):
    """Raised when OAuth authentication fails."""


class CitrixAPIError(DatadogAPIError):
    """Raised when Citrix API returns an error."""
