# Copyright (C) 2026 Crest Data.
# All rights reserved

"""Validation module for Citrix DaaS integration configuration parameters."""

from datadog_checks.base.errors import ConfigurationError

from . import crest_data_systems_citrix_daas_constants as constants
from .crest_data_systems_citrix_daas_errors import InvalidAPIKeyError


class ConfigValidator:
    """Validates and normalizes configuration parameters for the integration."""

    def __init__(self, instance_check):
        """Initialize the ConfigValidator.

        Args:
            instance_check: The Datadog check instance object.
        """
        self.instance_check = instance_check

        self.client_id = self.instance_check.instance.get("client_id")
        self.client_secret = self.instance_check.instance.get("client_secret")
        self.customer_id = self.instance_check.instance.get("customer_id")
        self.region = self.instance_check.instance.get("region", "US")
        self.data_to_collect = self.instance_check.instance.get("data_to_collect")
        self.min_collection_interval = self.instance_check.instance.get("min_collection_interval", 3600)

    def validate_configuration(self):
        """Main validation method that orchestrates all configuration validations."""
        try:
            self.validate_params()
            self.validate_client_id()
            self.validate_client_secret()
            self.validate_customer_id()
            self.validate_region()
            self.validate_data_to_collect()
            self.min_collection_interval_validation()
            self.initialize_auth_and_validation()

            success_msg = "Configuration validation successful."
            self.instance_check.logger.info(success_msg)
            self.instance_check.ingest_service_check_and_event(
                flag="CONF",
                status=0,
                message=success_msg,
            )
        except ConfigurationError as e:
            error_msg = f"Configuration validation failed: {e}"
            self.instance_check.logger.error(error_msg)
            self.instance_check.ingest_service_check_and_event(
                flag="CONF",
                status=2,
                message=error_msg,
            )
            raise

    def _validate_string_param(self, param_name, param_value):
        """Validate a string parameter for type and emptiness.

        Args:
            param_name: Name of the parameter being validated.
            param_value: Value of the parameter to validate.

        Raises:
            ConfigurationError: If validation fails.
        """
        if not param_value:
            error_msg = f"Required parameter '{param_name}' is missing or empty."
            self.instance_check.logger.error(error_msg)
            raise ConfigurationError(error_msg)

        if not isinstance(param_value, str):
            error_msg = f"Parameter '{param_name}' must be a string."
            self.instance_check.logger.error(error_msg)
            raise ConfigurationError(error_msg)

        if len(param_value.strip()) == 0:
            error_msg = f"Parameter '{param_name}' cannot be empty."
            self.instance_check.logger.error(error_msg)
            raise ConfigurationError(error_msg)

    def validate_params(self):
        """Validate that all required parameters are present and not empty."""
        required_params = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "customer_id": self.customer_id,
        }

        for param_name, param_value in required_params.items():
            if not param_value:
                error_msg = f"Required parameter '{param_name}' is missing or empty."
                self.instance_check.logger.error(error_msg)
                raise ConfigurationError(error_msg)

    def validate_client_id(self):
        """Validate client_id parameter format and presence."""
        self._validate_string_param("client_id", self.client_id)

    def validate_client_secret(self):
        """Validate client_secret parameter format and presence."""
        self._validate_string_param("client_secret", self.client_secret)

    def validate_customer_id(self):
        """Validate customer_id parameter format and presence."""
        self._validate_string_param("customer_id", self.customer_id)

    def validate_region(self):
        """Validate region parameter.

        Accepts region in any case (upper, lower, or mixed) and normalizes it.
        Valid regions: US, EU, AP-S, JP
        """
        # Define valid regions with their canonical forms
        valid_regions_mapping = {
            "us": "US",
            "eu": "EU",
            "ap-s": "AP-S",
            "jp": "JP",
        }

        # Normalize the region to lowercase for case-insensitive comparison
        region_lower = self.region.lower() if self.region else ""

        # Check if the normalized region is valid
        if region_lower not in valid_regions_mapping:
            valid_regions = list(valid_regions_mapping.values())
            error_msg = f"Parameter 'region' must be one of {valid_regions} (case-insensitive). Got: '{self.region}'"
            self.instance_check.logger.error(error_msg)
            raise ConfigurationError(error_msg)

        # Normalize the region to its canonical form
        self.region = valid_regions_mapping[region_lower]
        self.instance_check.logger.debug(
            f"Region validated and normalized to: {self.region}"  # noqa: G004
        )

    def validate_data_to_collect(self):
        """Validate data_to_collect parameter.

        Validates that:
        1. If parameter is not present (None), defaults to all data types
        2. If parameter is present, it must be a list
        3. List cannot be empty
        4. All items in list must be valid data types from ALLOWED_DATA_TO_COLLECT
        """
        # Check if parameter is not present - default to all data types
        if self.data_to_collect is None:
            self.data_to_collect = constants.ALLOWED_DATA_TO_COLLECT
            self.instance_check.logger.info(
                f"Parameter 'data_to_collect' not specified. "  # noqa: G004
                f"Collecting all data types: {constants.ALLOWED_DATA_TO_COLLECT}"
            )
            return

        # Explicitly check if parameter is present but not a list
        if not isinstance(self.data_to_collect, list):
            error_msg = f"Parameter 'data_to_collect' must be a list. Got type: {type(self.data_to_collect).__name__}"
            self.instance_check.logger.error(error_msg)
            raise ConfigurationError(error_msg)

        # Check if list is empty
        if len(self.data_to_collect) == 0:
            error_msg = (
                "Parameter 'data_to_collect' cannot be an empty list. "
                f"Allowed values: {constants.ALLOWED_DATA_TO_COLLECT}"
            )
            self.instance_check.logger.error(error_msg)
            raise ConfigurationError(error_msg)

        # Validate each data type in the list
        invalid_types = []
        for data_type in self.data_to_collect:
            if data_type not in constants.ALLOWED_DATA_TO_COLLECT:
                invalid_types.append(data_type)

        # If any invalid types found, raise error with all invalid types listed
        if invalid_types:
            error_msg = (
                f"Invalid data type(s) in 'data_to_collect': {invalid_types}. "
                f"Allowed values: {constants.ALLOWED_DATA_TO_COLLECT}"
            )
            self.instance_check.logger.error(error_msg)
            raise ConfigurationError(error_msg)

        # Log successful validation
        self.instance_check.logger.info(
            f"Parameter 'data_to_collect' validated successfully. "  # noqa: G004
            f"Will collect: {self.data_to_collect}"
        )

    def min_collection_interval_validation(self):
        """Validate min_collection_interval parameter."""
        if not isinstance(self.min_collection_interval, (int, float)):
            error_msg = "Parameter 'min_collection_interval' must be a number."
            self.instance_check.logger.error(error_msg)
            raise ConfigurationError(error_msg)

        if self.min_collection_interval < 900:
            error_msg = "Parameter 'min_collection_interval' must be at least 900 seconds."
            self.instance_check.logger.error(error_msg)
            raise ConfigurationError(error_msg)

        if self.min_collection_interval > 64800:
            error_msg = "Parameter 'min_collection_interval' must not exceed 64800 seconds (24 hours)."
            self.instance_check.logger.error(error_msg)
            raise ConfigurationError(error_msg)

    def initialize_auth_and_validation(self):
        """Initialize authentication and validate Datadog API key."""
        self.validate_dd_logs_enabled()

    def validate_dd_logs_enabled(self):
        """Validate Datadog API key."""
        if not self.instance_check._logs_enabled:
            error_msg = "Datadog logs_enabled must be set to True."
            self.instance_check.logger.error(error_msg)
            raise InvalidAPIKeyError(error_msg)

        self.instance_check.logger.debug("Datadog logs_enabled validation successful.")
        self.instance_check.ingest_service_check_and_event(
            flag="LOGS",
            status=0,
            message="Datadog logs_enabled is set to True.",
        )
