# Copyright (C) 2026 Crest Data.
# All rights reserved

"""Logging utility module with file and line number tracking."""

import os
from inspect import getframeinfo, stack

from .crest_data_systems_citrix_daas_constants import LOG_MESSAGE_FORMAT


class Logger:
    """Provides structured logging with automatic source location tracking."""

    def __init__(self, instance_check):
        """Initialize the Logger.

        Args:
            instance_check: The Datadog check instance object.
        """
        self.instance_check = instance_check
        self.base_str = LOG_MESSAGE_FORMAT

    def debug(self, msg):
        """Log debug level message.

        Args:
            msg: Message to log.
        """
        caller = getframeinfo(stack()[1][0])
        debug_msg = self.base_str.format(os.path.basename(caller.filename), caller.lineno, msg)
        self.instance_check.log.debug(debug_msg)

    def error(self, msg):
        """Log error level message.

        Args:
            msg: Message to log.
        """
        caller = getframeinfo(stack()[1][0])
        err_msg = self.base_str.format(os.path.basename(caller.filename), caller.lineno, msg)
        self.instance_check.log.error(err_msg)

    def info(self, msg):
        """Log info level message.

        Args:
            msg: Message to log.
        """
        caller = getframeinfo(stack()[1][0])
        info_msg = self.base_str.format(os.path.basename(caller.filename), caller.lineno, msg)
        self.instance_check.log.info(info_msg)

    def warning(self, msg):
        """Log warning level message.

        Args:
            msg: Message to log.
        """
        caller = getframeinfo(stack()[1][0])
        warn_msg = self.base_str.format(os.path.basename(caller.filename), caller.lineno, msg)
        self.instance_check.log.warning(warn_msg)

    def critical(self, msg):
        """Log critical level message.

        Args:
            msg: Message to log.
        """
        caller = getframeinfo(stack()[1][0])
        critical_msg = self.base_str.format(os.path.basename(caller.filename), caller.lineno, msg)
        self.instance_check.log.critical(critical_msg)

    def exception(self, msg):
        """Log exception level message.

        Args:
            msg: Message to log.
        """
        caller = getframeinfo(stack()[1][0])
        excp_msg = self.base_str.format(os.path.basename(caller.filename), caller.lineno, msg)
        self.instance_check.log.exception(excp_msg)
