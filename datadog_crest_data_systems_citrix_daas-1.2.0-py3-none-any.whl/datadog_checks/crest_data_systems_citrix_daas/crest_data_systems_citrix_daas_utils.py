# Copyright (C) 2026 Crest Data.
# All rights reserved

"""Utility functions for Citrix DaaS integration."""


def get_nested_value(data, path, default=None):
    """Retrieve a nested value from a dictionary.

    Args:
        data: The dictionary to search in.
        path: The path to the value, with levels separated by dots.
        default: The value to return if the path is not found.

    Returns:
        any: The value at the specified path, or the default value if not found.
    """
    levels = path.split(".")
    current = data
    for level in levels:
        current = current.get(level, {})
    return current if current != {} else default
