# Copyright (C) 2026 Crest Data.
# All rights reserved

"""Client module for managing Citrix DaaS data collection workflows."""

from datadog_checks.base.errors import ConfigurationError

from . import crest_data_systems_citrix_daas_constants as constants
from .crest_data_systems_citrix_daas_client_api import CitrixDaasAPI
from .crest_data_systems_citrix_daas_datasets import DATASET_CONFIG_MAP
from .crest_data_systems_citrix_daas_utils import get_nested_value


class CitrixDaasClient:
    """Manages data collection from Citrix DaaS APIs with checkpointing and pagination."""

    def __init__(self, instance_check):
        """Initialize the CitrixDaasClient.

        Args:
            instance_check: The Datadog check instance object.
        """
        self.instance_check = instance_check
        self.citrix_daas_api = None
        self.host = instance_check.hostname

        self.client_id = self.instance_check.config_validator.client_id
        self.client_secret = self.instance_check.config_validator.client_secret
        self.customer_id = self.instance_check.config_validator.customer_id
        self.region = self.instance_check.config_validator.region
        self.data_to_collect = self.instance_check.config_validator.data_to_collect

    def setup(self):
        """Establish connection and authenticate with Citrix DaaS API."""
        try:
            self.citrix_daas_api = CitrixDaasAPI(
                self.instance_check,
                client_id=self.client_id,
                client_secret=self.client_secret,
                customer_id=self.customer_id,
                region=self.region,
            )
            site_mapping = self.citrix_daas_api.authenticate()
            success_msg = "Connection with Citrix DaaS API is successful."
            self.instance_check.logger.info(success_msg)
            self.instance_check.ingest_service_check_and_event(
                flag="CONF",
                status=0,
                message=success_msg,
            )
        except ConfigurationError as ce:
            err_msg = f"Configuration Error: {ce}"
            self.instance_check.logger.error(err_msg)
            self.instance_check.ingest_service_check_and_event(
                flag="CONF",
                status=2,
                message=err_msg,
            )
            raise
        except RuntimeError as re:
            err_msg = f"Runtime Error during setup: {re}"
            self.instance_check.logger.error(err_msg)
            self.instance_check.ingest_service_check_and_event(
                flag="CONF",
                status=2,
                message=err_msg,
            )
            raise
        except Exception as e:
            err_msg = f"Unexpected error during setup: {e}"
            self.instance_check.logger.error(err_msg)
            self.instance_check.ingest_service_check_and_event(
                flag="CONF",
                status=2,
                message=err_msg,
            )
            raise
        return site_mapping

    def set_initial_checkpoint(self, timestamp_obj, data_type):
        """Set initial checkpoint for first-time data collection.

        Args:
            timestamp_obj: Timestamp object to update.
            data_type: Type of data being collected.
        """

        initial_timestamp = self.citrix_daas_api.get_last_18h_timestamp(constants.CITRIX_TIMESTAMP_FORMAT)

        if data_type == constants.CONFIG_LOG_OPERATIONS_DATA_TYPE:
            timestamp_obj[data_type] = {}

            for site_id in self.citrix_daas_api.instance_ids.keys():
                site_checkpoint_key = f"{data_type}-{site_id}-last-ingested-time"
                timestamp_obj[data_type][site_checkpoint_key] = initial_timestamp
        else:
            checkpoint_key = f"{data_type}-last-ingested-time"
            existing_checkpoint = timestamp_obj.get(checkpoint_key)

            if existing_checkpoint is None:
                timestamp_obj[checkpoint_key] = initial_timestamp
                self.instance_check.logger.info(
                    f"Set initial checkpoint for '{data_type}': {initial_timestamp}"  # noqa: G004
                )

    def _get_config_log_endtime_filter(self, site_id, timestamp_obj, data_type):
        """Get EndTime filter value for a specific site.

        Args:
            site_id: Site ID to get filter for.
            timestamp_obj: Timestamp object with checkpoints.
            data_type: Data type being collected.

        Returns:
            str: Formatted EndTime filter value for ConfigLog API.
        """
        site_checkpoint_key = f"{data_type}-{site_id}-last-ingested-time"
        last_checkpoint = timestamp_obj.get(data_type, {}).get(site_checkpoint_key)

        if last_checkpoint:
            time_filter = last_checkpoint
            self.instance_check.logger.info(
                f"Site '{site_id}': Using checkpoint time: '{last_checkpoint}'"  # noqa: G004
            )
        else:
            time_filter = self.citrix_daas_api.get_last_18h_timestamp(constants.CITRIX_TIMESTAMP_FORMAT)
            self.instance_check.logger.info(
                f"Site '{site_id}': No checkpoint found. Using last 18 hours: '{time_filter}'"  # noqa: G004
            )

        return time_filter

    def _extract_continuation_token(self, response):
        """Extract continuation token from response (case-insensitive).

        Args:
            response: API response dictionary.

        Returns:
            str or None: Continuation token if found, None otherwise.
        """
        for key in response.keys():
            if key.lower() == "continuationtoken":
                return response[key]
        return None

    def _paginate_api_call(
        self, api_method, data_type, pagination_type="citrix_monitor_service", items_key="value", **api_kwargs
    ):
        """Generic pagination handler for API calls."""
        all_items = []
        page_number = 1

        if pagination_type == "citrix_monitor_service":
            return self._paginate_with_skip_top(api_method, data_type, items_key, all_items, page_number, **api_kwargs)
        elif pagination_type == "citrix_daas_service":
            return self._paginate_with_token(api_method, data_type, items_key, all_items, page_number, **api_kwargs)
        else:
            raise ValueError(
                f"Invalid pagination_type: {pagination_type}. Must be 'citrix_monitor_service' or 'citrix_daas_service'"
            )

    def _paginate_with_skip_top(self, api_method, data_type, items_key, all_items, page_number, **api_kwargs):
        """Handle Citrix Monitor Service pagination (skip/top)."""
        skip = 0
        page_size = constants.PAGE_SIZE

        while True:
            response = api_method(top=page_size, skip=skip, **api_kwargs)
            if not self._validate_and_log_response(response, data_type, page_number):
                break

            items = response.get(items_key, [])
            items_count = len(items)
            all_items.extend(items)

            self._log_pagination_progress(data_type, page_number, items_count, len(all_items))

            if items_count < page_size:
                info_msg = f"Reached last page for '{data_type}'"
                self.instance_check.logger.info(info_msg)
                break

            skip += page_size
            page_number += 1

        return all_items

    def _paginate_with_token(self, api_method, data_type, items_key, all_items, page_number, **api_kwargs):
        """Handle Citrix DaaS Service pagination (continuation tokens)."""
        continuation_token = None
        context_info = api_kwargs.pop('context_info', data_type)

        while True:
            response = api_method(continuation_token=continuation_token, **api_kwargs)
            if not self._validate_and_log_response(response, data_type, page_number, context_info):
                break

            items = response.get(items_key, [])
            items_count = len(items)
            all_items.extend(items)

            self._log_pagination_progress(data_type, page_number, items_count, len(all_items), context_info)

            continuation_token = self._extract_continuation_token(response)
            if not continuation_token:
                info_msg = f"{context_info}: No continuation token found. Reached last page.'"
                self.instance_check.logger.info(info_msg)
                break

            page_number += 1

        return all_items

    def _validate_and_log_response(self, response, data_type, page_number, context_info=None):
        """Validate response and log warnings if needed."""
        if not response:
            prefix = f"{context_info}: " if context_info else ""
            warning_msg = f"{prefix}Empty response received for '{data_type}' page '{page_number}'"
            self.instance_check.logger.warning(warning_msg)
            return False
        return True

    def _log_pagination_progress(self, data_type, page_number, items_count, total_count, context_info=None):
        """Log pagination progress consistently."""
        prefix = f"{context_info} " if context_info else ""
        info_msg = (
            f"{prefix}Page '{page_number}': Fetched '{items_count}' '{data_type}' records. "
            f"Total collected so far: '{total_count}'"
        )
        self.instance_check.logger.info(info_msg)

    def _collect_config_log_operations_for_site(self, site_id, end_time_filter):
        """Collect ConfigLog operations data for a single site.

        Args:
            site_id: Site ID to collect data for.
            end_time_filter: EndTime filter value in ConfigLog API format.

        Returns:
            list: List of operations for this site.
        """

        return self._paginate_api_call(
            api_method=self.citrix_daas_api.get_config_log_operations,
            data_type=constants.CONFIG_LOG_OPERATIONS_API_ENDPOINT,
            pagination_type="citrix_daas_service",
            items_key="Items",
            context_info=f"Site '{site_id}'",
            instance_id=site_id,
            end_time_filter=end_time_filter,
        )

    def _update_site_checkpoint(self, site_id, site_operations, timestamp_obj, data_type, checkpoint_field):
        """Update checkpoint for a specific site.

        Args:
            site_id: Site ID to update checkpoint for.
            site_operations: Operations collected for this site.
            timestamp_obj: Timestamp object to update.
            data_type: Data type being collected.
            checkpoint_field: Field name for checkpoint.

        Returns:
            dict: Updated timestamp object.
        """
        site_checkpoint_key = f"{data_type}-{site_id}-last-ingested-time"

        if site_operations:
            latest_checkpoint = self.get_checkpoint(site_operations, checkpoint_field)
            if latest_checkpoint:
                timestamp_obj[data_type][site_checkpoint_key] = latest_checkpoint
                self.instance_check.logger.info(
                    f"Site '{site_id}': Updated checkpoint to '{latest_checkpoint}'. "  # noqa: G004
                    f"Collected '{len(site_operations)}' records."
                )
        else:
            self.instance_check.logger.info(
                f"Site '{site_id}': No new records found."  # noqa: G004
            )

        return timestamp_obj

    def get_checkpoint(self, data, checkpoint_field):
        """Get the latest checkpoint from collected data.

        Since data is already ordered by the checkpoint field in ascending order
        (via $orderby parameter in API call), we can simply take the last record's
        checkpoint value instead of iterating through all records.

        Args:
            data: List of data records (ordered by checkpoint_field asc).
            checkpoint_field: Field name for checkpoint.

        Returns:
            str: Latest checkpoint value or None.
        """
        if not data:
            return None

        # Data is already sorted by checkpoint field in ascending order
        # So the last record has the latest checkpoint value
        last_record = data[-1]
        latest_checkpoint = get_nested_value(last_record, checkpoint_field)

        return latest_checkpoint

    def set_checkpoint(self, timestamp_obj, data_type, data, checkpoint_field):
        """Update checkpoint after successful data ingestion.

        Args:
            timestamp_obj: Timestamp object to update.
            data_type: Type of data.
            data: Collected data records.
            checkpoint_field: Field name for checkpoint.

        Returns:
            dict: Updated timestamp object.
        """
        if data:
            updated_checkpoint = self.get_checkpoint(data, checkpoint_field)
            if updated_checkpoint:
                timestamp_obj[f"{data_type}-last-ingested-time"] = updated_checkpoint
                self.instance_check.logger.info(
                    f"Updated checkpoint for '{data_type}': '{updated_checkpoint}'"  # noqa: G004
                )

        return timestamp_obj

    def _ingest_standard_data(self, timestamp_obj, data_type, checkpoint_field, api_method_name):
        """Generic ingest skeleton shared by all standard monitor-service datasets.

        Args:
            timestamp_obj: Timestamp object with checkpoints.
            data_type: Dataset identifier string (e.g. "sessions").
            checkpoint_field: OData field used for $filter, $orderby, and checkpoint storage.
            api_method_name: Name of the CitrixDaasAPI method to call.

        Returns:
            tuple: (updated_timestamp_obj, list_of_events)
        """
        checkpoint_key = f"{data_type}-last-ingested-time"
        last_checkpoint = timestamp_obj.get(checkpoint_key)
        filter_param = f"{checkpoint_field} gt {last_checkpoint}"

        try:
            self.instance_check.logger.info(
                f"Starting '{data_type}' data collection from checkpoint: '{last_checkpoint}'"  # noqa: G004
            )

            api_method = getattr(self.citrix_daas_api, api_method_name)
            all_records = self._paginate_api_call(
                api_method=api_method,
                data_type=data_type,
                pagination_type="citrix_monitor_service",
                filter_param=filter_param,
                orderby=f"{checkpoint_field} asc",
            )

            timestamp_obj = self.set_checkpoint(timestamp_obj, data_type, all_records, checkpoint_field)

            self.instance_check.logger.info(
                f"Completed '{data_type}' data collection. "  # noqa: G004
                f"Total records collected: '{len(all_records)}'"
            )
            return timestamp_obj, all_records

        except Exception as e:
            error_msg = f"Error collecting '{data_type}' data: {e}"
            self.instance_check.logger.exception(error_msg)
            return timestamp_obj, []

    def ingest_config_log_operations_data(self, timestamp_obj):
        """Ingest ConfigLog operations data from Citrix DaaS.

        This method collects ConfigLog operations data from the Citrix DaaS API.
        IMPORTANT: This API requires per-site-ID execution and uses continuation tokens
        for pagination instead of $skip/$top. Checkpoints are stored per site ID.

        Args:
            timestamp_obj: Timestamp object with checkpoints.

        Returns:
            tuple: (updated_timestamp_obj, list_of_events)
        """
        data_type = constants.CONFIG_LOG_OPERATIONS_DATA_TYPE
        checkpoint_field = constants.CONFIG_LOG_OPERATIONS_CHECKPOINT_FIELD
        all_operations = []

        try:
            for site_id, site_name in self.citrix_daas_api.instance_ids.items():
                self.instance_check.logger.info(
                    f"Starting '{data_type}' data collection for site '{site_name}' (ID: '{site_id}')"  # noqa: G004
                )

                # Get EndTime filter for this site
                end_time_filter = self._get_config_log_endtime_filter(site_id, timestamp_obj, data_type)

                # Collect data for this site
                site_operations = self._collect_config_log_operations_for_site(site_id, end_time_filter)

                # Add site_id to each record
                for operation in site_operations:
                    operation["_site_id"] = site_id

                all_operations.extend(site_operations)

                # Update checkpoint for this site
                timestamp_obj = self._update_site_checkpoint(
                    site_id, site_operations, timestamp_obj, data_type, checkpoint_field
                )

            self.instance_check.logger.info(
                f"Completed '{data_type}' data collection. "  # noqa: G004
                f"Total records collected across all sites: '{len(all_operations)}'"
            )
            return timestamp_obj, all_operations

        except Exception as e:
            error_msg = f"Error collecting '{data_type}' data: {e}"
            self.instance_check.logger.exception(error_msg)
            return timestamp_obj, []

    def collect_citrix_daas_data(self, dataset, timestamp_obj):
        """Route data collection to the appropriate ingest path.

        Standard datasets (those with checkpoint_field and api_method in DATASET_CONFIG_MAP)
        are handled by _ingest_standard_data. Datasets that require custom logic (e.g.
        configlogoperations) retain their own dedicated method.

        Args:
            dataset: Dataset identifier string (must match a key in DATASET_CONFIG_MAP).
            timestamp_obj: Timestamp object with checkpoints.

        Returns:
            tuple: (updated_timestamp_obj, list_of_events)
        """
        if dataset == constants.CONFIG_LOG_OPERATIONS_DATA_TYPE:
            return self.ingest_config_log_operations_data(timestamp_obj)

        config = DATASET_CONFIG_MAP.get(dataset)
        if config and "api_method" in config:
            return self._ingest_standard_data(
                timestamp_obj,
                data_type=dataset,
                checkpoint_field=config["checkpoint_field"],
                api_method_name=config["api_method"],
            )

        self.instance_check.logger.warning(f"Unknown dataset type: '{dataset}'")  # noqa: G004
        return timestamp_obj, []
