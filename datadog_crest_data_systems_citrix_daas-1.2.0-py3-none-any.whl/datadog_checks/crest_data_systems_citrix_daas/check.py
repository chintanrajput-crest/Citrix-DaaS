# Copyright (C) 2026 Crest Data.
# All rights reserved

"""Main check module for Citrix DaaS integration."""

import time
from datetime import datetime, timezone

try:
    import datadog_agent
except ImportError:
    from datadog_checks.base.stubs import datadog_agent

from datadog_checks.base.checks.logs.crawler.base import LogCrawlerCheck
from datadog_checks.base.checks.logs.crawler.stream import LogRecord, LogStream
from datadog_checks.base.utils.persistent_cache import config_set_persistent_cache_id

from . import crest_data_systems_citrix_daas_constants as constants
from .crest_data_systems_citrix_daas_client import CitrixDaasClient
from .crest_data_systems_citrix_daas_datasets import API_CONFIG
from .crest_data_systems_citrix_daas_logger import Logger
from .crest_data_systems_citrix_daas_validator import ConfigValidator


class CitrixDaasLogStream(LogStream):
    """Log stream for Citrix DaaS data collection using LogCrawlerCheck framework."""

    def __init__(self, check, name, dataset_config, citrix_daas_client, site_mapping):
        """Initialize the CitrixDaasLogStream.

        Args:
            check: The check instance.
            name: Stream name.
            dataset_config: Dataset configuration.
            citrix_daas_client: Citrix DaaS client instance.
        """
        super().__init__(check=check, name=name)
        self.logger = Logger(check)
        self.dataset_config = dataset_config
        self.dataset = dataset_config.get("dataset")
        self.citrix_daas_client = citrix_daas_client
        self.site_mapping = site_mapping

    def records(self, cursor=None):
        """Generator that yields LogRecord objects for Citrix DaaS data.

        Args:
            cursor: Checkpoint cursor from previous run.

        Yields:
            LogRecord: Log records with data and cursor.
        """
        try:
            timestamp_obj = self.initialize_timestamp(cursor)
            timestamp_obj, events = self.get_dataset_data(self.dataset, timestamp_obj)
            if self.dataset == constants.CONFIG_LOG_OPERATIONS_DATA_TYPE:
                latest_timestamp = timestamp_obj
            else:
                latest_timestamp = timestamp_obj.get(f"{self.dataset}-last-ingested-time")

            if events:
                for event in events:
                    record = self.create_log_record(event, latest_timestamp)
                    if record:
                        yield record

                info_msg = f"Successfully processed {len(events)} events for '{self.dataset}' dataset."
                self.logger.info(info_msg)
                return

        except Exception as e:
            error_msg = f"Error in records() for '{self.dataset}': {e}"
            self.logger.error(error_msg)
            raise

    def initialize_timestamp(self, cursor):
        """Extract timestamp object from cursor and set initial checkpoint if needed.

        This method checks if a cursor exists from a previous run. If it does,
        it uses that cursor. If not, it initializes a new timestamp object and
        sets the initial checkpoint to 18 hours ago.

        Args:
            cursor: Checkpoint cursor from previous run.

        Returns:
            dict: Timestamp object with checkpoint information.
        """
        if cursor:
            if self.dataset == constants.CONFIG_LOG_OPERATIONS_DATA_TYPE:
                last_timestamp_per_instance = cursor.get(constants.CONFIG_LOG_OPERATIONS_DATA_TYPE)
                if last_timestamp_per_instance:
                    info_msg = f"Cursor found for {self.dataset} | Last Timestamp: {last_timestamp_per_instance}"
                    self.logger.info(info_msg)
                    return cursor
            else:
                last_timestamp = cursor.get(f"{self.dataset}-last-ingested-time")
                info_msg = f"Cursor found for {self.dataset} | Last Timestamp: {last_timestamp}"
                self.logger.info(info_msg)
                return cursor

        self.logger.debug(f"No cursor found. Initializing cursor for {self.dataset}")  # noqa: G004
        # No cursor found - this is the first run, set initial checkpoint
        timestamp_obj = {}
        self.citrix_daas_client.set_initial_checkpoint(timestamp_obj, self.dataset)
        self.logger.debug(f"Initialized timestamp for {self.dataset}: {timestamp_obj}")  # noqa: G004
        self.logger.info(
            f"No cursor found for {self.dataset}. Set initial checkpoint to last 18 hours."  # noqa: G004
        )
        return timestamp_obj

    def get_dataset_data(self, dataset, timestamp_obj):
        """Fetch dataset-specific data.

        Args:
            dataset: Dataset type.
            timestamp_obj: Timestamp object.

        Returns:
            tuple: (updated_timestamp_obj, list_of_events)
        """
        return self.citrix_daas_client.collect_citrix_daas_data(dataset=dataset, timestamp_obj=timestamp_obj)

    def create_log_record(self, event, latest_timestamp):
        """Convert raw event into LogRecord.

        This method transforms the raw event data into a LogRecord object that
        can be ingested by Datadog. It adds metadata fields and creates a cursor
        for checkpointing.

        Args:
            event: Event data from the API.
            latest_timestamp: Latest checkpoint timestamp for this dataset.

        Returns:
            LogRecord: Log record object with data and cursor, or None if error.
        """
        try:
            if self.dataset == constants.CONFIG_LOG_OPERATIONS_DATA_TYPE:
                record_cursor = {
                    "dataset": self.dataset,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
                record_cursor.update(latest_timestamp)
            else:
                # Create cursor for checkpointing
                record_cursor = {
                    f"{self.dataset}-last-ingested-time": latest_timestamp,
                    "dataset": self.dataset,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }

            # Build service field name as per specification
            service_field_name = f"{constants.INTEGRATION_PREFIX}.service_name"

            ddtags = ",".join(self.check.instance.get("tags", []))
            ddtags += f",customer_id:{self.citrix_daas_client.customer_id}"

            # For ConfigLog operations, add site_id to ddtags if present in event
            if self.dataset == constants.CONFIG_LOG_OPERATIONS_DATA_TYPE:
                site_id = event.get("_site_id")
                if site_id:
                    site_name = self.site_mapping.get(site_id)
                    ddtags += f",site_id:{site_id},site_name:{site_name}"
                    # Remove the temporary _site_id field from the event
                    event.pop("_site_id", None)

            # Add metadata fields to the event
            event.update(
                {
                    service_field_name: f"{constants.INTEGRATION_PREFIX}.{self.dataset}",
                    "hostname": self.check.hostname,
                    "ddtags": ddtags,
                }
            )

            return LogRecord(data=event, cursor=record_cursor)
        except Exception as e:
            error_msg = f"Error processing event for '{self.dataset}': {e}"
            self.logger.error(error_msg)
            return None


class CrestDataSystemsCitrixDaasCheck(LogCrawlerCheck):
    """Main check class for Citrix DaaS integration."""

    __NAMESPACE__ = "crest_data_systems_citrix_daas"

    def __init__(self, name, init_config, instances):
        """Initialize the check.

        Args:
            name: Check name.
            init_config: Init configuration.
            instances: List of instances.
        """
        super(CrestDataSystemsCitrixDaasCheck, self).__init__(name, init_config, instances)

        self._logs_enabled = datadog_agent.get_config("logs_enabled")
        self.min_collection_interval = self.instance.get("min_collection_interval", 3600)
        self.logger = Logger(self)
        self.host = self.hostname
        self.config_validator = ConfigValidator(self)

        self.config_validator.validate_configuration()

    def persistent_cache_id(self):
        """Return unique cache ID for this integration.

        Returns:
            str: Cache ID.
        """
        return config_set_persistent_cache_id(self, instance_config_options=["customer_id"])

    def get_log_streams(self):
        """Define log streams for different Citrix DaaS data types.

        Returns:
            list: List of LogStream objects.
        """
        streams = []

        data_to_collect = self.config_validator.data_to_collect
        if not data_to_collect:
            data_to_collect = constants.ALLOWED_DATA_TO_COLLECT

        for dataset_config in API_CONFIG:
            dataset = dataset_config.get("dataset")

            if dataset in data_to_collect:
                stream_name = f"{dataset}_stream"
                stream = CitrixDaasLogStream(
                    check=self,
                    name=stream_name,
                    dataset_config=dataset_config,
                    citrix_daas_client=self.citrix_daas_client,
                    site_mapping=self.site_mapping,
                )
                streams.append(stream)
                info_msg = f"Created log stream for '{dataset}' dataset."
                self.logger.info(info_msg)
            else:
                self.logger.info(
                    f"Skipping dataset '{dataset}' - not in data_to_collect."  # noqa: G004
                )

        if not streams:
            warning_msg = "No log streams created."
            self.logger.warning(warning_msg)

        return streams

    def check(self, _):
        """Main check method called by Datadog Agent.

        Args:
            _: Unused parameter required by framework.
        """

        start_time = time.time()
        self.citrix_daas_client = CitrixDaasClient(instance_check=self)
        self.site_mapping = self.citrix_daas_client.setup()

        if self.citrix_daas_client.citrix_daas_api:
            self.logger.info("Start of the data collection.")
            self.process_streams()

        elapsed_time = time.time() - start_time
        info_msg = "End of the data collection. Time taken: {:.3f} seconds.".format(elapsed_time)
        self.logger.info(info_msg)

    def ingest_service_check_and_event(self, flag, **service_check_event_args):
        """Ingest Service Check and Event for milestones.

        Args:
            flag: Type of check - "API" or "CONF".
            **service_check_event_args: Arguments for service check and event.
        """
        if flag == "API":
            self.service_check(
                name=service_check_event_args.get("check_name", constants.STATUS_CHECK_NAME),
                status=service_check_event_args.get("status"),
                tags=service_check_event_args.get("tags", constants.API_VAL_TAG),
                message=service_check_event_args.get("message"),
            )
            self.event(
                {
                    "tags": service_check_event_args.get("tags", constants.API_VAL_TAG),
                    "msg_text": service_check_event_args.get("message"),
                    "msg_title": service_check_event_args.get("title", constants.API_VAL_TITLE),
                    "source_type_name": service_check_event_args.get("source_type", constants.API_VAL_SOURCE_TYPE),
                }
            )
        else:
            self.service_check(
                name=service_check_event_args.get("check_name", constants.CAN_CONNECT_CHECK_NAME),
                status=service_check_event_args.get("status"),
                tags=service_check_event_args.get("tags", constants.CONF_VAL_TAG),
                message=service_check_event_args.get("message"),
            )

            self.event(
                {
                    "tags": service_check_event_args.get("tags", constants.CONF_VAL_TAG),
                    "msg_text": service_check_event_args.get("message"),
                    "msg_title": service_check_event_args.get("title", constants.CONF_VAL_TITLE),
                    "source_type_name": service_check_event_args.get("source_type", constants.CONF_VAL_SOURCE_TYPE),
                }
            )
